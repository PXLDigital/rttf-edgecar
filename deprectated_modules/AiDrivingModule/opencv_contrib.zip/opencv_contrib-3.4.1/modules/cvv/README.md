GUI for Interactive Visual Debugging of Computer Vision Programs
================================================================

Simple code that you can add to your program that pops up a GUI allowing you to interactively and visually debug computer vision programs.
